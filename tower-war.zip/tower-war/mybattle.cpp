#include <QPainter>
#include <QPaintEvent>
#include <QMouseEvent>
#include <QString>
#include <QTimer>
#include "towerposition.h"
#include "towers.h"
#include "fightpoint.h"
#include "enemy.h"
#include "bullet.h"
#include "selectbutton.h"
#include "selectbutton2.h"
#include "calculate.h"
#include <QPixmap>
#include <QDebug>
#include <QPoint>
#include <QPushButton>
#include "mybattle.h"
static const int tower1Cost=300;
static const int tower2Cost=400;
static const int tower3Cost=500;
static const int towerupdate1Cost=300;
static const int towerupdate2Cost=400;
MyBattle::MyBattle(QWidget *parent) :
    QMainWindow(parent),
    m_waves(0),
    m_gameWin(false),
    m_gameEnd(false),
    m_playerHp(5),
    m_playerGlod(1000)
{
    this->setFixedSize(1122,600);
    addFightPoint();
    printTowerPosition();
    QTimer * timer=new QTimer(this);
    connect(timer,SIGNAL(timeout()),this,SLOT(updateMap()));
    timer->start(30);
    QTimer::singleShot(300,this,SLOT(gameStart()));
}
void MyBattle::gameStart()
{
    loadWaves();
}


void MyBattle::updateMap()
{
    foreach(Enemy * enemy,m_enemyList)
        enemy->move();
    foreach(Towers * towers,m_towersList)
        towers->checkEnemyInRange();
    update();
}
void MyBattle::paintEvent(QPaintEvent *){
    QPainter painter(this);
    QString path(":/battlefield.jpg");
    painter.drawPixmap(0,0,1122,600,path);
    if(m_gameEnd || m_gameWin)
        {
            QString text=m_gameEnd ? "YOU LOST":"YOU WIN";
            QPainter painter(this);
            painter.setPen(Qt::red);
            painter.drawText(rect(),Qt::AlignCenter,text);
            return ;
        }
        painter.drawPixmap(0,0,this->width(),this->height(),getPath());
        foreach(const TowerPosition & towerPos,m_towerPositionList)
        {
            if(!towerPos.m_hasTower)
            {
                towerPos.draw(&painter);
            }
        }
    foreach(const fightPoint *fightpoint,m_fightPointList)
        fightpoint->draw(&painter);
    foreach(const TowerPosition towerposition,m_towerPositionList)
        towerposition.draw(&painter);
    foreach(const Towers *towers,m_towersList)
        towers->draw(&painter);
    foreach(const Enemy * enemy,m_enemyList)
            enemy->draw(&painter);
    foreach(const Bullet * bullet,m_bulletList)
            bullet->draw(&painter);
    foreach(const selectButton * button,m_selectButtonList)
            button->draw(&painter);
    foreach(const selectButton2 * button2,m_selectButton2List)
            button2->draw(&painter);
    drawHp(&painter);
    drawGlod(&painter);
    drawWaves(&painter);
}
void MyBattle::addFightPoint()
{
    fightPoint *fightpoint1=new fightPoint(QPoint(1,325));
    m_fightPointList.push_back(fightpoint1);
    fightPoint *fightpoint2=new fightPoint(QPoint(561,325));
    fightpoint1->setNextFightPoint(fightpoint2);
    m_fightPointList.push_back(fightpoint2);
    fightPoint *fightpoint3=new fightPoint(QPoint(561,150));
    fightpoint2->setNextFightPoint(fightpoint3);
    m_fightPointList.push_back(fightpoint3);
    fightPoint *fightpoint4=new fightPoint(QPoint(750,150));
    fightpoint3->setNextFightPoint(fightpoint4);
    m_fightPointList.push_back(fightpoint4);
    fightPoint *fightpoint5=new fightPoint(QPoint(750,275));
    fightpoint4->setNextFightPoint(fightpoint5);
    m_fightPointList.push_back(fightpoint5);
    fightPoint *fightpoint6=new fightPoint(QPoint(1120,275));
    fightpoint5->setNextFightPoint(fightpoint6);
    m_fightPointList.push_back(fightpoint6);
}
void MyBattle::printTowerPosition()
{
    QPoint pos[]=
    {
        QPoint(50,100),
        QPoint(200,450),
        QPoint(800,150),
        QPoint(1000,400)
     };
    int len=sizeof(pos)/sizeof(pos[0]);
    for(int i=0;i<len;i++)
    {
        m_towerPositionList.push_back(pos[i]);
    }
}
bool MyBattle::canBuyTower1()
{
    if(m_playerGlod>=tower1Cost)
    {
        return true;
    }
    return false;
}

bool MyBattle::canBuyTower2()
{
    if(m_playerGlod>=tower2Cost)
    {
        return true;
    }
    return false;
}

bool MyBattle::canBuyTower3()
{
    if(m_playerGlod>=tower3Cost)
    {
        return true;
    }
    return false;
}
bool MyBattle::canUpdate1()
{
    if(m_playerGlod>=towerupdate1Cost)
    {
        return true;
    }
    return false;
}

bool MyBattle::canUpdate2()
{
    if(m_playerGlod>=towerupdate2Cost)
    {
        return true;
    }
    return false;
}
void MyBattle::mousePressEvent(QMouseEvent * event)
{
    QPoint pressPos=event->pos();
    auto it=m_towerPositionList.begin();
    while(it!=m_towerPositionList.end())
    {
        if(Qt::LeftButton==event->button())
        {
            if(it->containPoint(pressPos) && !it->hasButton() && !it->hasTower() && !it->hasButton2())
            {
                QPoint tmp(it->getPos().x()-35,it->getPos().y()-35);
                selectButton * button=new selectButton(tmp,this);
                m_selectButtonList.push_back(button);
                it->setButton(button);
                it->setHasButton(true);
                update();
                break;
            }
         else if(it->hasButton2() && it->getButton2()->containPos(pressPos) && !it->hasButton() && !it->containPoint(pressPos) &&it->hasTower())
            {
                if(pressPos.y()<(it->getButton2()->getPos().y()+25))
                {
                    if(canUpdate1() && !it->hasUpdate1() && it->hasTower())
                    {
                        it->setHasUpdate1(true);
                        m_playerGlod-=towerupdate1Cost;
                        it->get_tower()->reSetDamage(it->get_tower()->getDamage()+10);
                        it->get_tower()->levelChange();
                        //update();
                    }
                    else if(canUpdate2() && it->hasUpdate1() && !it->hasUpdate2())
                    {
                        it->setHasUpdate2(true);
                        m_playerGlod-=towerupdate2Cost;
                        it->get_tower()->reSetDamage(it->get_tower()->getDamage()+20);
                        it->get_tower()->levelChange();
                        //update();
                    }
                }
                else if(pressPos.y()>it->getButton2()->getPos().y()+25)
                {
                    awardGlod();
                    it->get_tower()->getRemoved();
                    it->setRemoveTower();
                }
                it->getButton2()->getRemoved();
                it->setButton2(NULL);
                it->setHasButton2(false);
                update();
                break;
            }
            else if(it->hasButton() && !it->hasTower() && it->getButton()->containPos(pressPos))
            {
                if(pressPos.x()<it->getButton()->getPos().x()+35)
                {
                    if(canBuyTower1())
                    {
                        it->setHasTower1(true);
                        m_playerGlod-=tower1Cost;
                        QString path=":/tower1.jpg";
                        Towers * towers=new Towers(it->centerPos(),this,path,10);
                        it->setTower(towers);
                        m_towersList.push_back(towers);
                        update();
                    }
                }
                else if(pressPos.x()>it->getButton()->getPos().x()+35 && pressPos.x()<it->getButton()->getPos().x()+70)
                {
                    if(canBuyTower2())
                    {
                        it->setHasTower2(true);
                        m_playerGlod-=tower2Cost;
                        QString path=":/tower2.jpg";
                        Towers * tower=new Towers(it->centerPos(),this,path,15);
                        it->setTower(tower);
                        m_towersList.push_back(tower);
                        update();
                    }
                }
                else if(pressPos.x()>it->getButton()->getPos().x()+70 && pressPos.x()<it->getButton()->getPos().x()+105)
                {
                    if(canBuyTower3())
                    {
                        it->setHasTower3(true);
                        m_playerGlod-=tower3Cost;
                        QString path=":/tower3.jpg";
                        Towers * tower=new Towers(it->centerPos(),this,path,20);
                        it->setTower(tower);
                        m_towersList.push_back(tower);
                        update();
                    }
                }
                it->getButton()->getRemoved();
                it->setButton(NULL);
                it->setHasButton(false);
                update();
                break;
            }
        }
        else if(Qt::RightButton==event->button())
        {
            if(it->containPoint(pressPos) && (!it->hasButton2()) && it->hasTower())
            {
                it->setHasButton2(true);
                QPoint tmp(it->getPos().x()+35,it->getPos().y());
                selectButton2 * button2=new selectButton2(tmp,this,100,50);
                button2->setTower(it->get_tower());
                m_selectButton2List.push_back(button2);
                it->setButton2(button2);
                update();
                break;
            }
        }
        ++it;
    }
}
void MyBattle::setPath(QString path)
{
    m_path=path;
}

QString MyBattle::getPath()
{
    return m_path;
}

void MyBattle::getHpDamage()
{
    m_playerHp-=1;
    if(m_playerHp<=0)
    {
        doGameOver();
    }
}

void MyBattle::doGameOver()
{
    if(!m_gameEnd)
    {
        m_gameEnd=true;
    }
}

void MyBattle::removeTower(Towers * towers)
{
    Q_ASSERT(towers);
    m_towersList.removeOne(towers);
    delete towers;
}

void MyBattle::removeEnemy(Enemy *enemy)
{
    Q_ASSERT(enemy);
    m_enemyList.removeOne(enemy);
    delete enemy;
    if(m_enemyList.empty())
    {
        ++m_waves;
        if(!loadWaves())
        {
            m_gameWin=true;
        }
    }
}

void MyBattle::removeButton(selectButton *button)
{
    Q_ASSERT(button);
    m_selectButtonList.removeOne(button);
    delete button;
}

void MyBattle::removeButton2(selectButton2 *button)
{
    Q_ASSERT(button);
    m_selectButton2List.removeOne(button);
    delete button;
}

bool MyBattle::loadWaves()
{
    if(m_waves>=6)
    {
        return false;
    }

    int enemyStartInterval[]={100,500,600,1000,3000,6000};
    for(int i=0;i<5;++i)
    {
        fightPoint * startWayPoint;
        if(getPath()==":/wolf.jpg")
        {
            int a=rand()%100;
            if(a<50)
            {
                startWayPoint=m_fightPointList.first();
            }
            if(a>=50)
            {
               startWayPoint=m_fightPointList[5];
            }
        }
        else
        {
            startWayPoint=m_fightPointList.first();
        }
        Enemy * enemy=new Enemy(startWayPoint,this);
        m_enemyList.push_back(enemy);
        enemy->reShowup(40+20*(0+m_waves));
        QTimer::singleShot(enemyStartInterval[i],enemy,SLOT(doActive()));
    }
    return true;
}

QList<Enemy *> MyBattle::getEnemyList()
{
    return m_enemyList;
}

void MyBattle::removeBullet(Bullet *bullet)
{
    Q_ASSERT(bullet);
    m_bulletList.removeOne(bullet);
    delete bullet;
}

void MyBattle::addBullet(Bullet *bullet)
{
    Q_ASSERT(bullet);
    m_bulletList.push_back(bullet);
}

void MyBattle::awardGlod()
{
    m_playerGlod+=200;
    update();
}

void MyBattle::drawWaves(QPainter *painter) const
{
    painter->save();
    painter->setPen(Qt::red);
    painter->drawText(QRect(500,5,100,25),QString("WAVES: %1").arg(m_waves+1));
    painter->restore();
}

void MyBattle::drawHp(QPainter *painter) const
{
    painter->save();
    painter->setPen(Qt::red);
    painter->drawText(QRect(30,5,100,25),QString("HP: %1").arg(m_playerHp));
    painter->restore();
}

void MyBattle::drawGlod(QPainter *painter) const
{
    painter->save();
    painter->setPen(Qt::red);
    painter->drawText(QRect(300,5,100,25),QString("GLOD: %1").arg(m_playerGlod));
}
