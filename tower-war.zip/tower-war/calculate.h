#ifndef CALCULATE_H
#define CALCULATE_H

#endif // CALCULATE_H
#include <QPoint>
#include <cmath>
inline bool collsionWithAttackRange(QPoint p1,int r1,QPoint p2,int r2)
{
    int x=p1.x()-p2.x();
    int y=p1.y()-p2.y();
    int dis=x*x+y*y;
    if(dis<(r1+r2)*(r1+r2))
    {
        return true;
    }
    return false;
}
