#include "towers.h"
#include "mybattle.h"
#include "calculate.h"
#include "bullet.h"
#include "enemy.h"
#include <QPoint>
#include <QPainter>
#include <QString>
#include <QPixmap>
#include <QTimer>
#include <QVector2D>
#include <QtMath>
const QSize Towers::m_fixedSize(35,35);
Towers::Towers(QPoint pos,MyBattle * game,const QPixmap &sprite,int damage):
    m_attacking(false),
    m_attackRange(70),
    m_damage(damage),
    m_fireRate(1200),
    m_level(1),
    m_chooseEnemy(NULL),
    m_game(game),
    m_pos(pos),
    m_sprite(sprite)
{
    m_fireRateTime=new QTimer(this);
    connect(m_fireRateTime,SIGNAL(timeout()),this,SLOT(shootBullet()));
}

Towers::~Towers()
{
    delete m_fireRateTime;
    m_fireRateTime=NULL;
    m_chooseEnemy=NULL;
    m_game=NULL;
    delete m_chooseEnemy;
}
void Towers::draw(QPainter *painter) const
{
    painter->save();
    painter->setPen(Qt::green);
    painter->drawEllipse(m_pos,m_attackRange,m_attackRange);
    painter->drawText(QRect(this->m_pos.x()-30,this->m_pos.y()+15,100,25),QString("level: %1").arg(m_level));
    painter->drawPixmap(m_pos.x()-m_fixedSize.width()/2,m_pos.y()-m_fixedSize.height()/2-10,m_sprite);
}
void Towers::chooseEnemyFromAttack(Enemy *enemy)
{
    m_chooseEnemy=enemy;
    attackEnemy();
    m_chooseEnemy->getAttack(this);
}

void Towers::attackEnemy()
{
    m_fireRateTime->start(m_fireRate);
}

void Towers::shootBullet()
{
    Bullet * bullet=new Bullet(m_pos,m_chooseEnemy->get_pos(),m_damage,m_chooseEnemy,m_game);
    bullet->move();
    m_game->addBullet(bullet);
}

void Towers::targetKilled()
{
    if(m_chooseEnemy)
    {
        m_chooseEnemy=NULL;
    }
    m_fireRateTime->stop();
}

void Towers::lostSightOfEnemy()
{
    m_chooseEnemy->getAway(this);
    if(m_chooseEnemy)
    {
        m_chooseEnemy=NULL;
    }
    m_fireRateTime->stop();
}

void Towers::checkEnemyInRange()
{
    if(m_chooseEnemy)//如果有了攻击的敌人
    {
        QVector2D normalized(m_chooseEnemy->get_pos()-m_pos);
        normalized.normalize();
        if(!collsionWithAttackRange(m_pos,m_attackRange,m_chooseEnemy->get_pos(),1))
        {
            lostSightOfEnemy();
        }
    }
    else
    {
        QList<Enemy * > enemyList=m_game->getEnemyList();
        foreach(Enemy * enemy,enemyList)
            if(collsionWithAttackRange(m_pos,m_attackRange,enemy->get_pos(),1))
            {
                chooseEnemyFromAttack(enemy);
                break;
            }
    }
}

void Towers::reSetDamage(int damage)
{
    m_damage=damage;
}

void Towers::levelChange()
{
    m_level++;
}

int Towers::getLevel()
{
    return m_level;
}

int Towers::getDamage()
{
    return m_damage;
}

Enemy * Towers::getAttackEnemy()
{
    return m_chooseEnemy;
}

void Towers::getRemoved()
{
    if(getAttackEnemy())
    {
        getAttackEnemy()->getAway(this);
    }
    m_game->removeTower(this);
}
