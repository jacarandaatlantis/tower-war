#include "enemy.h"
#include "fightpoint.h"
#include "mybattle.h"
#include "calculate.h"
#include "towers.h"
#include <QPainter>
#include <QPoint>
#include <QSize>
#include <QPixmap>
#include <QVector2D>
const QSize Enemy::m_fixedSize(20,20);

Enemy::Enemy(fightPoint *startfightpoint,MyBattle *game,const QPixmap & sprite):
    QObject(0),
    m_game(game),
    m_pos(startfightpoint->getPos()),
    m_sprite(sprite)
{
    m_maxHp=30;
    m_currentHp=m_maxHp;
    m_walkingSpeed=1;
    m_activity=false;
    m_destinationFightPoint=startfightpoint->getNextFightPoint();
}
Enemy::~Enemy()
{
    m_attackTowersList.clear();
    m_destinationFightPoint=NULL;
    m_game=NULL;
}
void Enemy::draw(QPainter *painter)const
{
    if(!m_activity)
    {
        return;
    }
    painter->save();
        static const int birthBarWidth=m_fixedSize.width();
        QPoint birthBarPoint=m_pos+QPoint(-m_fixedSize.width()/2,-m_fixedSize.height());
        painter->setPen(Qt::NoPen);
        painter->setBrush(Qt::red);
        QRect birthBarBackRect(birthBarPoint,QSize(birthBarWidth,2));
        painter->drawRect(birthBarBackRect);

        painter->setBrush(Qt::green);
        QRect birthBarRect(birthBarPoint,QSize((double)m_currentHp/m_maxHp*birthBarWidth,2));
        painter->drawRect(birthBarRect);

        QPoint tmp(m_pos.x()-m_fixedSize.width()/2,m_pos.y()-m_fixedSize.height()/2);
        painter->drawPixmap(tmp.x(),tmp.y(),m_sprite);
        painter->restore();
}
void Enemy::move()
{
    if(!m_activity)
    {
        return;
    }
    if(collsionWithAttackRange(m_pos,1,m_destinationFightPoint->getPos(),1))
    {
        if(m_destinationFightPoint->getNextFightPoint())
        {
            m_pos=m_destinationFightPoint->getPos();
            m_destinationFightPoint=m_destinationFightPoint->getNextFightPoint();
        }
        else
        {
            m_game->getHpDamage();
            m_game->removeEnemy(this);
            return ;
        }
    }
    else
    {
        QPoint targetPoint=m_destinationFightPoint->getPos();
        double movementSpeed=m_walkingSpeed;
        QVector2D normalized(targetPoint-m_pos);
        normalized.normalize();
        m_pos=m_pos+normalized.toPoint()*movementSpeed;
    }
}
void Enemy::doActivity()
{
    m_activity=true;
}

QPoint Enemy::get_pos()
{
    return m_pos;
}

void Enemy::getAttack(Towers *towers)
{
    m_attackTowersList.push_back(towers);
}

void Enemy::getDamage(int damage)
{
    m_currentHp-=damage;
    if(m_currentHp<=0)
    {
        m_game->awardGlod();
        getKilled();
    }
}

void Enemy::getKilled()
{
    if(m_attackTowersList.empty())
    {
        return;
    }
    else
    {
        foreach(Towers * towers,m_attackTowersList)
            towers->targetKilled();
        m_game->removeEnemy(this);
    }
}

void Enemy::getAway(Towers *towers)
{
    m_attackTowersList.removeOne(towers);
}

void Enemy::reShowup(int maxHp)
{
    m_maxHp=maxHp;
    m_currentHp=maxHp;
}
