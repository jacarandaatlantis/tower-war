#include "fightpoint.h"
#include <QPoint>
#include <QPainter>

fightPoint::fightPoint(QPoint pos):
    m_pos(pos),
    m_nextFightPoint(NULL)
{
}
void fightPoint::setNextFightPoint(fightPoint *nextFightPoint)
{
    this->m_nextFightPoint=nextFightPoint;
}
fightPoint *fightPoint::getNextFightPoint()
{
    return this->m_nextFightPoint;
}
const QPoint fightPoint::getPos()
{
    return this->m_pos;
}
void fightPoint::draw(QPainter *painter)const
{
    painter->save();
    painter->setPen(Qt::yellow);
    painter->drawEllipse(m_pos,5,5);
    painter->drawEllipse(m_pos,2,2);
    if(m_nextFightPoint)
    {
        painter->drawLine(m_pos,m_nextFightPoint->getPos());
    }
    painter->restore();
}
