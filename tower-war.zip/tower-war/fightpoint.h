#ifndef FIGHTPOINT_H
#define FIGHTPOINT_H

#include <QPainter>
#include <QPoint>

class fightPoint
{
public:
    fightPoint(QPoint pos);
    void setNextFightPoint(fightPoint *nextFightPoint);
    fightPoint *getNextFightPoint();
    const QPoint getPos();
    void draw(QPainter *painter)const;
private:
    QPoint m_pos;
    fightPoint *m_nextFightPoint;
};

#endif // FIGHTPOINT_H
