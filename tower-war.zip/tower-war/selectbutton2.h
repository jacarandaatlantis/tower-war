#ifndef SELECTBUTTON2_H
#define SELECTBUTTON2_H

#include <QObject>
#include <QPainter>
#include <QRect>
#include <QPoint>

#include "mybattle.h"
#include "towers.h"

class MyBattle;
class Towers;

class selectButton2:QObject
{
    Q_OBJECT
private:
    MyBattle * m_game;
    Towers * m_tower;
    QPoint m_pos;
    int m_width;
    int m_height;
public:
    selectButton2(QPoint pos,MyBattle* game,int width,int height);
    ~selectButton2();
    void draw(QPainter * painter)const;
    void getRemoved();
    Towers * getTower();
    void setTower(Towers *towers);
    bool containPos(QPoint pos);
    QPoint getPos();
};

#endif // SELECTBUTTON2_H
