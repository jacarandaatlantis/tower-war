#ifndef ENEMY_H
#define ENEMY_H

#include <QObject>
#include <QPoint>
#include <QPixmap>
#include <QPainter>
#include <QSize>

#include "fightpoint.h"
#include "mybattle.h"
#include "towers.h"
#include "towerposition.h"
class MyBattle;
class QPainter;
class fightPoint;
class Towers;
class TowerPosition;
class Enemy:public QObject
{
    Q_OBJECT
public:
    Enemy(fightPoint *start,MyBattle *game,const QPixmap&sprite=QPixmap(":/tiger.jpg"));
    ~Enemy();
    void draw(QPainter *painter)const;
    void move();
    QPoint get_pos();
    void getAttack(Towers *towers);
    void getDamage(int damage);
    void getKilled();
    void getAway(Towers *towers);
    void reShowup(int maxHp);
private slots:
    void doActivity();
private:
    int m_maxHp;
    int m_currentHp;
    int m_walkingSpeed;
    bool m_activity;
    fightPoint *m_destinationFightPoint;
    MyBattle *m_game;
    QPoint m_pos;
    QPixmap m_sprite;
    QList<Towers *>m_attackTowersList;
    static const QSize m_fixedSize;

};
#endif // ENEMY_H
