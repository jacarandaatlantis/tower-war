#ifndef SELECTBUTTON_H
#define SELECTBUTTON_H

#include <QObject>
#include <QPoint>
#include <QPixmap>
#include <QPainter>
#include <QString>
#include "mybattle.h"
class MyBattle;
class selectButton :QObject
{
    Q_OBJECT
private:
    MyBattle * m_game;
    QPoint m_pos;
    int m_width;
    int m_height;
    QString m_selectBoxImagePath[3];
public:
    selectButton(QPoint pos,MyBattle * game,int width=50,int height=120);
    ~selectButton();
    void draw(QPainter * painter)const;
    void getRemoved();
    bool containPos(QPoint pos);
    QPoint getPos();
};

#endif // SELECTBUTTON_H
