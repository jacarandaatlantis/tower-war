#ifndef MYBATTLE_H
#define MYBATTLE_H

#include <QMainWindow>
#include <QPainter>
#include "towers.h"
#include <QList>
#include <QPaintEvent>
#include <QString>
#include <QMouseEvent>
#include "fightpoint.h"
#include <towerposition.h>
#include <QPainter>
#include <QPaintEvent>
#include <QMouseEvent>
#include <QString>
#include "towerposition.h"
#include "enemy.h"
#include "bullet.h"
#include "selectbutton.h"
#include "selectbutton2.h"
class fightPoint;
class Bullet;
class Enemy;
class TowerPosition;
class Towers;
class selectButton;
class selectButton2;
class MyBattle : public QMainWindow
{
    Q_OBJECT
public:
    explicit MyBattle(QWidget *parent = nullptr);
    void show_Battle();
    void set_towers();
    void addFightPoint();
    void printTowerPosition();
    bool canBuyTower1();
    bool canBuyTower2();
    bool canBuyTower3();
    bool canUpdate1();
    bool canUpdate2();
    void getHpDamage();
    void awardGlod();
    void drawHp(QPainter * painter)const;
    void drawGlod(QPainter * painter)const;
    void drawWaves(QPainter * painter)const;
    void doGameOver();
    void removeEnemy(Enemy * enemy);
    void removeBullet(Bullet * bullet);
    void removeButton(selectButton *button);
    void removeButton2(selectButton2 *button);
    void removeTower(Towers * towers);
    void addBullet(Bullet * bullet);
    QString getPath();
    void setPath(QString path);
    bool loadWaves();
    QList<Enemy *>  getEnemyList();
    void gameStart();
    void updateMap();
    void chooseBack();
protected:
    void paintEvent(QPaintEvent *);
    void mousePressEvent(QMouseEvent *);
private:
    QList<Towers*>m_towersList;
    QList<fightPoint*>m_fightPointList;
    QList<TowerPosition>m_towerPositionList;
    QList<Enemy *> m_enemyList;
    QList<Bullet *>m_bulletList;
    QList<selectButton *> m_selectButtonList;
    QList<selectButton2 *> m_selectButton2List;
    int m_waves;
    bool m_gameWin;
    bool m_gameEnd;
    int m_playerHp;
    int m_playerGlod;
    QString m_path;
};

#endif // MYBATTLE_H
