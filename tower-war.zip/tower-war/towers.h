#ifndef TOWERS_H
#define TOWERS_H

#include <QObject>
#include <QPoint>
#include <QSize>
#include <QPixmap>
#include "enemy.h"
#include "bullet.h"
#include "mybattle.h"
class QPainter;
class Enemy;
class MainWindow;
class QTimer;
class MyBattle;

class Towers :QObject
{
    Q_OBJECT
public:
    Towers(QPoint pos,MyBattle * game,const QPixmap & sprite,int damage);
    ~Towers();
    Towers();
    void draw(QPainter * painter)const;
    void attackEnemy();
    void targetKilled();
    void chooseEnemyFromAttack(Enemy * enemy);
    void removeBullet();
    void lostSightOfEnemy();
    void checkEnemyInRange();
    void reSetDamage(int damage);
    int getDamage();
    void levelChange();
    int getLevel();
    void getRemoved();
    Enemy * getAttackEnemy();
protected slots:
    void shootBullet();

protected:
    bool m_attacking;
    int m_attackRange;
    int m_damage;
    int m_fireRate;
    int m_level;
    Enemy * m_chooseEnemy;
    MyBattle * m_game;
    QTimer * m_fireRateTime;
    const QPoint m_pos;
    const QPixmap m_sprite;
    static const QSize m_fixedSize;
};
#endif // TOWERS_H
